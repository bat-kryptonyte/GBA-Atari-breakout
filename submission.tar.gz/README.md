## GBA ATARI-BREAKOUT
### AUTHOR: JEFFREY DENG
### BACKGROUND
Breakout is an arcade video game developed and published by Atari, Inc. and released on May 13, 1976. It was designed by Steve Wozniak, based on conceptualization from Nolan Bushnell and Steve Bristow who were influenced by the seminal 1972 Atari arcade game Pong. In Breakout, a layer of bricks lines the top third of the screen and the goal is to destroy them all by repeatedly bouncing a ball off a paddle into them. 
### CONTROLS
up-key: start the game
backspace: return to main screen
left-key: move the paddle left
right-key: move the paddle right


