/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=24x8 gradient gradient.png 
 * Time-stamp: Sunday 04/02/2023, 04:27:21
 * 
 * Image Information
 * -----------------
 * gradient.png 24@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GRADIENT_H
#define GRADIENT_H

extern const unsigned short gradient[192];
#define GRADIENT_SIZE 384
#define GRADIENT_LENGTH 192
#define GRADIENT_WIDTH 24
#define GRADIENT_HEIGHT 8

#endif

