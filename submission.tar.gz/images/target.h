/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x10 target target.png 
 * Time-stamp: Sunday 04/02/2023, 05:47:41
 * 
 * Image Information
 * -----------------
 * target.png 20@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TARGET_H
#define TARGET_H

extern const unsigned short target[200];
#define TARGET_SIZE 400
#define TARGET_LENGTH 200
#define TARGET_WIDTH 20
#define TARGET_HEIGHT 10

#endif

