/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 wasted wasted.png 
 * Time-stamp: Sunday 04/02/2023, 18:07:12
 * 
 * Image Information
 * -----------------
 * wasted.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WASTED_H
#define WASTED_H

extern const unsigned short wasted[38400];
#define WASTED_SIZE 76800
#define WASTED_LENGTH 38400
#define WASTED_WIDTH 240
#define WASTED_HEIGHT 160

#endif

